Official info about translation: http://codex.wordpress.org/Translating_WordPress



Select language(for exapmle:spanish) from Poedit save this in "languages" folder located in  kaya-innova-page-widgets file and save new copy as kaya-innova-page-widgets-es_ES.po for Spanish.
And then use translating program to translate it to Spanish language.

add this "define('WPLANG', 'es_ES');" in wp_config.php file.